// assets/js/storage.js

const PM_STORAGE_KEYS = {
  requests: "pm_requests",        // [{sicil, dateKey, createdAt, isLate}]
  draws: "pm_draws",              // { [dateKey]: {dateKey, createdAt, bySicil, list: [sicil], approved: [sicil]} }
  penalties: "pm_penalties",      // { [sicil]: number }
  config: "pm_config",            // {maxDaysAhead, weightRandom, ...}
  extraTime: "pm_extraTime",      // { [dateKey]: {deadline: isoString} }
  pinSession: "pm_pin_session"    // sadece bilgi amaçlı, gerçek kontrol sessionStorage'ta
};

function pmGetJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.error("pmGetJSON", key, e);
    return fallback;
  }
}

function pmSetJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error("pmSetJSON", key, e);
  }
}

// Config
function pmGetConfig() {
  const cfg = pmGetJSON(PM_STORAGE_KEYS.config, null);
  if (!cfg) {
    pmSetJSON(PM_STORAGE_KEYS.config, PM_CONFIG_DEFAULT);
    return { ...PM_CONFIG_DEFAULT };
  }
  return { ...PM_CONFIG_DEFAULT, ...cfg };
}

function pmSaveConfig(partial) {
  const current = pmGetConfig();
  const merged = { ...current, ...partial };
  pmSetJSON(PM_STORAGE_KEYS.config, merged);
}

// Personel
function pmGetPersonnelList() {
  // data.js içindeki listeyi aynen döndürüyoruz
  return PERSONEL_LISTESI;
}

function pmFindPersonnelBySicil(sicil) {
  return pmGetPersonnelList().find(p => p.sicil === String(sicil));
}

// Talepler
function pmGetAllRequests() {
  return pmGetJSON(PM_STORAGE_KEYS.requests, []);
}

function pmSaveAllRequests(list) {
  pmSetJSON(PM_STORAGE_KEYS.requests, list);
}

// Belirli personel & gün için talep
function pmUpsertRequest(sicil, dateKey, isLate) {
  const all = pmGetAllRequests();
  const idx = all.findIndex(r => r.sicil === sicil && r.dateKey === dateKey);
  const now = new Date().toISOString();
  if (idx === -1) {
    all.push({ sicil, dateKey, createdAt: now, isLate: !!isLate });
  } else {
    all[idx].createdAt = now;
    all[idx].isLate = !!isLate;
  }
  pmSaveAllRequests(all);
}

function pmDeleteRequest(sicil, dateKey) {
  const all = pmGetAllRequests().filter(r => !(r.sicil === sicil && r.dateKey === dateKey));
  pmSaveAllRequests(all);
}

function pmGetRequestsByDate(dateKey) {
  return pmGetAllRequests().filter(r => r.dateKey === dateKey);
}

function pmGetRequestsBySicil(sicil) {
  return pmGetAllRequests().filter(r => r.sicil === sicil);
}

// Kura
function pmGetAllDraws() {
  return pmGetJSON(PM_STORAGE_KEYS.draws, {});
}

function pmSaveAllDraws(drawsObj) {
  pmSetJSON(PM_STORAGE_KEYS.draws, drawsObj);
}

function pmGetDrawByDate(dateKey) {
  const all = pmGetAllDraws();
  return all[dateKey] || null;
}

function pmSaveDraw(dateKey, draw) {
  const all = pmGetAllDraws();
  all[dateKey] = draw;
  pmSaveAllDraws(all);
}

// Ceza puanları
function pmGetPenalties() {
  return pmGetJSON(PM_STORAGE_KEYS.penalties, {});
}

function pmSavePenalties(obj) {
  pmSetJSON(PM_STORAGE_KEYS.penalties, obj);
}

function pmAddPenalty(sicil, delta) {
  const p = pmGetPenalties();
  const current = p[sicil] || 0;
  let next = current + delta;
  if (next < 0) next = 0;
  if (next > 5) next = 5;
  p[sicil] = next;
  pmSavePenalties(p);
}

function pmGetPenaltyOf(sicil) {
  return pmGetPenalties()[sicil] || 0;
}

// Extra Time (ek talep süresi)
function pmGetExtraTime() {
  return pmGetJSON(PM_STORAGE_KEYS.extraTime, {});
}

function pmSaveExtraTime(obj) {
  pmSetJSON(PM_STORAGE_KEYS.extraTime, obj);
}

function pmSetDeadlineForDate(dateKey, deadlineISO) {
  const all = pmGetExtraTime();
  all[dateKey] = { deadline: deadlineISO };
  pmSaveExtraTime(all);
}

function pmGetDeadlineForDate(dateKey) {
  const all = pmGetExtraTime();
  return all[dateKey] ? new Date(all[dateKey].deadline) : null;
}

// Varsayılanlara dön (admin)
function pmResetConfigToDefaults() {
  pmSetJSON(PM_STORAGE_KEYS.config, PM_CONFIG_DEFAULT);
  pmSetJSON(PM_STORAGE_KEYS.penalties, {});
  // Talepler & kuralar silinmez.
}
