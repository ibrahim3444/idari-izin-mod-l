// assets/js/history.js

function pmGetPastLeavesCount(sicil, days = 60) {
  const draws = pmGetAllDraws();
  const now = new Date();
  const limit = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);

  let count = 0;
  for (const dateKey in draws) {
    const draw = draws[dateKey];
    if (!draw.approved || !Array.isArray(draw.approved)) continue;
    const drawDate = new Date(dateKey);
    if (drawDate >= limit && drawDate <= now) {
      if (draw.approved.includes(sicil)) {
        count++;
      }
    }
  }
  return count;
}
