// ============================================================
// data.js (FIXED VERSION)
// Tüm sistemle tam uyumlu hale getirilmiş sürüm
// ============================================================

// Sistem kurucusu bilgileri (admin panel giriş şifresi dahil)
const SISTEM_KURUCUSU = {
    ad: "İbrahim Halil ALDEMİR",
    gizliSifre: "208211",       // admin.html için giriş
    personelSifre: "208211"     // kurucu personel girişi
};

// Varsayılan personel şifresi
const DEFAULT_PERSONEL_SIFRE = "1234";

// ============================================================
// PERSONELLER (tam liste)
// ============================================================

const PERSONEL_LISTESI = [
    // Komuta
    { sicil: "937833", ad: "Recep DEMİRCİ", rol: "komuta", sifre: "937833--" },
    { sicil: "944950", ad: "Soner KOLUMAN", rol: "komuta", sifre: "944950++" },

    // Personeller
    { sicil: "944989", ad: "Ali ÇINAR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "969665", ad: "Erol SARI", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "948783", ad: "Harun AKDEMİR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961754", ad: "M.Mustafa KARADOĞAN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "960152", ad: "Hüseyin İVGEN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "967027", ad: "Bilal SANCAR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "937835", ad: "Ömer KARAÇOBAN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "960895", ad: "Ergin AĞDAĞ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "951818", ad: "Ünal ELKÜN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "966725", ad: "Ercan YAKUT", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944995", ad: "İlker SEVİNDİK", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "951734", ad: "Serdar NARİNÇ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "969661", ad: "Kemal KARAKURT", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944975", ad: "Ramazan Hurşit TAŞ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },

    // Kurucu personel (özel şifre)
    { sicil: "961726", ad: "İbrahim Halil ALDEMİR", rol: "personel", sifre: SISTEM_KURUCUSU.personelSifre },

    { sicil: "937843", ad: "Zülküf ALTAÇ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "969670", ad: "Emre SUİÇMEZ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "937837", ad: "Sinan GÜNEŞLİK", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961731", ad: "İbrahim UZER", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "962132", ad: "Uğurcan ÖZDEMİR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944951", ad: "Sezgin YASAK", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "966912", ad: "Hüseyin YİĞİT", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944967", ad: "Ramazan ŞENAY", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "951499", ad: "Mehmet ÖZSULAR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944893", ad: "İsmail KOCADAĞ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944957", ad: "Erhan CEYLAN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961625", ad: "Ali Osman ARMAĞAN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "944992", ad: "Saffet SAKAR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961673", ad: "Emre KAŞ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "967212", ad: "Raşit ABAYLI", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961676", ad: "Emre YILMAZ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "970399", ad: "Yusuf ŞAHİN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "966712", ad: "Ferhat GÖKHAN", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961815", ad: "Osman KARADAĞ", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961737", ad: "İsmail ÇOLAK", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE },
    { sicil: "961862", ad: "Tuncay BULAKBASAR", rol: "personel", sifre: DEFAULT_PERSONEL_SIFRE }
];

// ============================================================
// KOMUTA LİSTESİ (app.js ile %100 uyumlu)
// ============================================================

const KOMUTA_LISTESI = PERSONEL_LISTESI
    .filter(p => p.rol === "komuta")
    .map(k => ({
        sicil: k.sicil,
        ad: k.ad,
        sifre: k.sifre
    }));

// ============================================================
// Varsayılan ayarlar
// ============================================================

const VARSAYILAN_AYARLAR = {
    talepGunSayisi: 7,
    agirlikRandom: 50,
    agirlikHistory: 30,
    agirlikTime: 20
};
