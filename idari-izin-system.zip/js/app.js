// assets/js/app.js

// Session keys (sadece sessionStorage)
const PM_SESSION_KEYS = {
  pinOk: "pm_pin_ok",
  role: "pm_role",         // "personel" | "komuta" | "admin"
  sicil: "pm_sicil"
};

function pmRequirePin() {
  const ok = sessionStorage.getItem(PM_SESSION_KEYS.pinOk) === "1";
  if (!ok) {
    window.location.href = "index.html";
  }
}

function pmSetPinOk() {
  sessionStorage.setItem(PM_SESSION_KEYS.pinOk, "1");
}

function pmSetSession(role, sicil) {
  sessionStorage.setItem(PM_SESSION_KEYS.role, role);
  sessionStorage.setItem(PM_SESSION_KEYS.sicil, sicil);
}

function pmClearSession() {
  sessionStorage.removeItem(PM_SESSION_KEYS.role);
  sessionStorage.removeItem(PM_SESSION_KEYS.sicil);
}

// PIN giriş kontrolü (index.html içinde kullanılacak)
function pmHandlePinSubmit(pinInputId, onSuccess) {
  const pinInput = document.getElementById(pinInputId);
  const pin = pinInput.value.trim();
  const cfg = pmGetConfig();

  if (pin === cfg.pin) {
    pmSetPinOk();
    onSuccess();
  } else {
    pmShowPopup("Geçersiz PIN.");
  }
}

// PERSONEL GİRİŞ
function pmHandlePersonelLogin(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const sicil = form.sicil.value.trim();
    const sifre = form.sifre.value.trim();
    const p = pmFindPersonnelBySicil(sicil);
    if (!p) {
      pmShowPopup("Personel bulunamadı.");
      return;
    }
    const expected = p.sifre || PM_CONFIG_DEFAULT.defaultPersonnelPassword;
    if (sifre !== expected) {
      pmShowPopup("Şifre hatalı.");
      return;
    }
    pmSetSession("personel", p.sicil);
    window.location.href = "personel.html";
  });
}

// KOMUTA GİRİŞ
function pmHandleKomutaLogin(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const sicil = form.sicil.value.trim();
    const sifre = form.sifre.value.trim();

    const p = pmFindPersonnelBySicil(sicil);
    if (!p || (p.rol !== "komuta" && p.rol !== "personel")) {
      pmShowPopup("Komuta personeli değil.");
      return;
    }

    const cfg = pmGetConfig();
    const komutaPw = cfg.komutaPasswords[sicil];
    if (!komutaPw || sifre !== komutaPw) {
      pmShowPopup("Komuta şifresi hatalı.");
      return;
    }

    pmSetSession("komuta", sicil);
    window.location.href = "komuta.html";
  });
}

// ADMIN GİRİŞ
function pmHandleAdminLogin(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const sifre = form.sifre.value.trim();
    const cfg = pmGetConfig();
    if (sifre !== cfg.adminPassword) {
      pmShowPopup("Admin şifresi hatalı.");
      return;
    }
    pmSetSession("admin", "ADMIN");
    window.location.href = "admin.html";
  });
}

// KURA ALGORİTMASI
function pmRunDrawForDate(dateKey, bySicil) {
  const existing = pmGetDrawByDate(dateKey);
  if (existing) {
    pmShowPopup("Bu tarih için kura zaten çekilmiş.");
    return existing;
  }

  const cfg = pmGetConfig();
  const requests = pmGetRequestsByDate(dateKey);

  if (!requests.length) {
    pmShowPopup("Bu tarih için talep bulunmuyor.");
    return null;
  }

  const penalties = pmGetPenalties();

  // Puanlama
  const scored = requests.map(r => {
    const pastCount = pmGetPastLeavesCount(r.sicil, 60);
    const penalty = penalties[r.sicil] || 0;

    const randomScore = Math.random() * 100 * cfg.weightRandom;

    // Geçmiş kullanım: ne kadar çok kullanmışsa o kadar düşsün
    const pastScore = (0 - pastCount) * cfg.weightPastUsage * 10;

    // Erken başvuru bonusu: daha erken tarihli createdAt daha yüksek
    const createdTime = new Date(r.createdAt).getTime();
    const maxCreated = Math.max(...requests.map(rr => new Date(rr.createdAt).getTime()));
    const minCreated = Math.min(...requests.map(rr => new Date(rr.createdAt).getTime()));
    let earlyFactor = 1;
    if (maxCreated !== minCreated) {
      earlyFactor = 1 - ((createdTime - minCreated) / (maxCreated - minCreated)); // ilk başvuran ~1, son başvuran ~0
    }
    const earlyScore = earlyFactor * 100 * cfg.weightEarlyRequest;

    const penaltyScore = -penalty * 5;

    const total = randomScore + pastScore + earlyScore + penaltyScore;

    return {
      sicil: r.sicil,
      dateKey,
      score: total
    };
  });

  // Skora göre sırala
  scored.sort((a, b) => b.score - a.score);

  const list = scored.map(s => s.sicil);

  const draw = {
    dateKey,
    createdAt: new Date().toISOString(),
    bySicil,
    list,
    approved: []
  };

  pmSaveDraw(dateKey, draw);
  pmShowPopup("Kura çekildi.");
  return draw;
}

// Onay verme (Komuta)
function pmApproveLeave(dateKey, sicil) {
  const draw = pmGetDrawByDate(dateKey);
  if (!draw) return;
  if (!draw.approved.includes(sicil)) {
    draw.approved.push(sicil);
    pmSaveDraw(dateKey, draw);
  }
}

// Admin: "izin kullanmadı" düzeltmesi
function pmRemoveApprovedLeave(dateKey, sicil) {
  const draw = pmGetDrawByDate(dateKey);
  if (!draw) return;
  draw.approved = draw.approved.filter(s => s !== sicil);
  pmSaveDraw(dateKey, draw);
}

// Ek süre açma (Komuta)
function pmExtendDeadlineForToday(minutes) {
  const todayKey = pmTodayKey();
  const currentDeadline = pmGetDeadlineForDate(todayKey);
  const base = currentDeadline && currentDeadline > new Date() ? currentDeadline : new Date();
  const newDeadline = new Date(base.getTime() + minutes * 60 * 1000);
  pmSetDeadlineForDate(todayKey, newDeadline.toISOString());
  pmShowPopup(`Başvuru süresi ${minutes} dakika uzatıldı.`);
}

function pmIsRequestAllowedForDate(dateKey) {
  const cfg = pmGetConfig();
  const today = new Date();
  const target = new Date(dateKey);
  const diffDays = Math.ceil((target - today) / (24 * 60 * 60 * 1000));
  if (diffDays < 0) return false;
  if (diffDays > cfg.maxRequestDaysAhead) return false;

  const deadline = pmGetDeadlineForDate(dateKey);
  if (!deadline) {
    // varsayılan: gün sonuna kadar
    const end = new Date(target);
    end.setHours(23, 59, 59, 999);
    return new Date() <= end;
  }
  return new Date() <= deadline;
}

// Ana sayfa: bugünün kura & izinliler
function pmRenderTodayOnIndex(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const todayKey = pmTodayKey();
  const draw = pmGetDrawByDate(todayKey);
  if (!draw) {
    el.innerHTML = "<p>Bugün için kura çekilmemiş.</p>";
    return;
  }
  if (!draw.approved.length) {
    el.innerHTML = "<p>Kura çekildi, henüz izin onayı verilmemiş.</p>";
    return;
  }

  const personnel = pmGetPersonnelList();
  const html = draw.approved
    .map((sicil, i) => {
      const p = personnel.find(x => x.sicil === sicil);
      const name = p ? p.adSoyad : "Bilinmeyen";
      const masked = pmMaskSicil(sicil);
      return `<div class="card card-success">
        <span class="badge">${i + 1}</span>
        <div>${masked} – ${name}</div>
      </div>`;
    })
    .join("");

  el.innerHTML = html;
}

// Yardımcı: oturumu kontrol et
function pmRequireRole(roles) {
  pmRequirePin();
  const role = sessionStorage.getItem(PM_SESSION_KEYS.role);
  if (!roles.includes(role)) {
    window.location.href = "index.html";
  }
}
