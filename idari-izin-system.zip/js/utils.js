// assets/js/utils.js

function pmTodayKey() {
  const now = new Date();
  return pmDateToKey(now);
}

function pmDateToKey(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function pmKeyToHuman(dateKey) {
  const [y, m, d] = dateKey.split("-");
  return `${d}.${m}.${y}`;
}

function pmMaskSicil(sicil) {
  sicil = String(sicil);
  if (sicil.length < 4) return sicil;
  const first2 = sicil.slice(0, 2);
  const last2 = sicil.slice(-2);
  return `${first2}**${last2}`;
}

function pmShowPopup(message) {
  alert(message); // İleride modal'e çevrilebilir.
}

// Saat aralığı kontrolü - HH:MM
function pmIsBetweenTime(startHHMM, endHHMM) {
  const [sH, sM] = startHHMM.split(":").map(Number);
  const [eH, eM] = endHHMM.split(":").map(Number);
  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const startMinutes = sH * 60 + sM;
  const endMinutes = eH * 60 + eM;
  return nowMinutes >= startMinutes && nowMinutes <= endMinutes;
}

function pmIsFriday(date = new Date()) {
  return date.getDay() === 5; // 0=pazar, 5=cuma
}

function pmClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}
